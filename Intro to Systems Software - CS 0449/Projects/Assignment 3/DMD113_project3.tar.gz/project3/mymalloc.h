#include <unistd.h>

void *my_firstfit_malloc(int size);

void my_free(void *ptr);

void printList();
